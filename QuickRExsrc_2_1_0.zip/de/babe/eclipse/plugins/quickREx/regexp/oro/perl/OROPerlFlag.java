/*******************************************************************************
 * Copyright (c) 2005 Bastian Bergerhoff and others
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution.
 * 
 * Contributors:
 *     Andreas Studer - initial API and implementation
 *******************************************************************************/
package de.babe.eclipse.plugins.quickREx.regexp.oro.perl;

import org.apache.oro.text.regex.Perl5Compiler;
import de.babe.eclipse.plugins.quickREx.regexp.Flag;

/**
 * Class OROPerlFlag.
 * This represents all Flags from the ORO Perl implementation.
 *
 * @author Andreas Studer
 * @version 1.0
 * @since 2.1
 */
public class OROPerlFlag extends Flag
{
    public static final Flag PERL_EXTENDED = new OROPerlFlag("de.babe.eclipse.plugins.quickREx.regexp.oro.perl.EXTENDED", Perl5Compiler.EXTENDED_MASK, "Extended",
    "In this mode, the compiled regular expression is treated as a Perl5 extended pattern\n(i.e., a pattern using the /x modifier). This option tells the compiler\nto ignore whitespace that is not backslashed or within a character\nclass. It also tells the compiler to treat the # character as a metacharacter\nintroducing a comment as in Perl. In other words, the # character will comment\nout any text in the regular expression between it and the next newline.\nThe intent of this option is to allow you to divide your\npatterns into more readable parts. It is provided to maintain\ncompatibility with Perl5 regular expressions, although it will not\noften make sense to use it in Java.");
    public static final Flag PERL_SINGLELINE = new OROPerlFlag("de.babe.eclipse.plugins.quickREx.regexp.oro.perl.SINGLELINE", Perl5Compiler.SINGLELINE_MASK, "Singleline",
    "In this mode, the compiled regular expression treats input as being a single line.\nThis option affects the interpretation of the ^ and $ metacharacters. When\nthis mask is used, the ^ metacharacter matches at the beginning of the\ninput, and the $ metacharacter matches at the end of the input.\nThe ^ and $ metacharacters will not match at the beginning and end of lines occurring\nbetween the beginning and end of the input. Additionally,\nthe . metacharacter will match newlines when an expression is compiled with\nSINGLELINE_MASK, unlike its default behavior.");
    public static final Flag PERL_MULTILINE = new OROPerlFlag("de.babe.eclipse.plugins.quickREx.regexp.oro.perl.MULTILINE", Perl5Compiler.MULTILINE_MASK, "Multiline",
    "In this mode, the compiled regular expression treats input as having multiple lines.\nThis option affects the interpretation of the ^ and $ metacharacters. When\nthis mask is used, the ^ metacharacter matches at the beginning of every\nline, and the $ metacharacter matches at the end of every line.\nAdditionally the . metacharacter will not match newlines when an expression is compiled with\nMULTILINE_MASK, which is its default behavior.");
    public static final Flag PERL_CASE_INSENSITIVE = new OROPerlFlag("de.babe.eclipse.plugins.quickREx.regexp.oro.perl.CASE_INSENSITIVE", Perl5Compiler.CASE_INSENSITIVE_MASK, "Case insensitive",
    "In this mode, the compiled regular expression is case insensitive.");

    static {
        flags.put(PERL_EXTENDED.getCode(), PERL_EXTENDED);
        flags.put(PERL_SINGLELINE.getCode(), PERL_SINGLELINE);
        flags.put(PERL_MULTILINE.getCode(), PERL_MULTILINE);
        flags.put(PERL_CASE_INSENSITIVE.getCode(), PERL_CASE_INSENSITIVE);
    }

    private OROPerlFlag(String code, int flag, String name, String description)
    {
        super(code, flag, name, description);
        // TODO Auto-generated constructor stub
    }
}
