/*******************************************************************************
 * Copyright (c) 2005 Bastian Bergerhoff and others
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution.
 * 
 * Contributors:
 *     Andreas Studer - initial API and implementation
 *******************************************************************************/
package de.babe.eclipse.plugins.quickREx.regexp.jdk;

import java.util.regex.Pattern;
import de.babe.eclipse.plugins.quickREx.regexp.Flag;

/**
 * Class JavaFlag.
 * This represents all flags for the Java Regex implementation.
 *
 * @author Andreas Studer
 * @version 1.0
 * @since 2.1
 */
public class JavaFlag extends Flag
{
    public static final Flag JDK_CANON_EQ = new JavaFlag("de.babe.eclipse.plugins.quickREx.regexp.jdk.CANON_EQ", Pattern.CANON_EQ, "Canonical equivalence", 
    "When this flag is specified then two characters will be considered to match if,\nand only if, their full canonical decompositions match.\nThe expression \"a\\u030A\", for example, will match the string\n\"?\" when this flag is specified. By default, matching does not\ntake canonical equivalence into account.\n\nThere is no embedded flag character for enabling\ncanonical equivalence.");
    public static final Flag JDK_UNICODE_CASE = new JavaFlag("de.babe.eclipse.plugins.quickREx.regexp.jdk.UNICODE_CASE", Pattern.UNICODE_CASE, "Unicode case", 
    "When this flag is specified then case-insensitive matching, when enabled by the\nCASE_INSENSITIVE flag, is done in a manner consistent with\nthe Unicode Standard. By default, case-insensitive matching\nassumes that only characters in the US-ASCII charset are being matched.\n\nUnicode-aware case folding can also be enabled via the embedded flag\nexpression (?u).");
    public static final Flag JDK_DOTALL = new JavaFlag("de.babe.eclipse.plugins.quickREx.regexp.jdk.DOTALL", Pattern.DOTALL, "Dotall",
    "In dotall mode, the expression . matches any character, including a line terminator.\nBy default this expression does not match line terminators.\n\nDotall mode can also be enabled via the embedded flag expression (?s).");
    public static final Flag JDK_MULTILINE = new JavaFlag("de.babe.eclipse.plugins.quickREx.regexp.jdk.MULTILINE", Pattern.MULTILINE, "Multiline",
    "In multiline mode the expressions ^ and $ match just after or just before, respectively,\na line terminator or the end of the input sequence. By default\nthese expressions only match at the beginning and the end of the\nentire input sequence.\n\nMultiline mode can also be enabled via the embedded flag expression (?m).");
    public static final Flag JDK_COMMENTS = new JavaFlag("de.babe.eclipse.plugins.quickREx.regexp.jdk.COMMENTS", Pattern.COMMENTS, "Comments",
    "In this mode, whitespace is ignored, and embedded comments starting with # are ignored\nuntil the end of a line.\n\nComments mode can also be enabled via the embedded flag expression (?x).");
    public static final Flag JDK_CASE_INSENSITIVE = new JavaFlag("de.babe.eclipse.plugins.quickREx.regexp.jdk.CASE_INSENSITIVE", Pattern.CASE_INSENSITIVE, "Case insensitive",
    "In this mode, case-insensitive matching is performed. By default, case-insensitive\nmatching assumes that only characters in the US-ASCII charset are being\nmatched. Unicode-aware case-insensitive matching can be\nenabled by specifying the UNICODE_CASE flag in conjunction with this flag.\n\nCase-insensitive matching can also be enabled via the embedded flag expression (?i).");
    public static final Flag JDK_UNIX_LINES = new JavaFlag("de.babe.eclipse.plugins.quickREx.regexp.jdk.UNIX_LINES", Pattern.UNIX_LINES, "Unix lines",
    "In this mode, only the '\\n' line terminator is recognized in the behavior of ., ^, and $.\n\nUnix lines mode can also be enabled via the embedded flag expression (?d).");
    static {
        flags.put(JDK_CANON_EQ.getCode(), JDK_CANON_EQ);
        flags.put(JDK_UNICODE_CASE.getCode(), JDK_UNICODE_CASE);
        flags.put(JDK_DOTALL.getCode(), JDK_DOTALL);
        flags.put(JDK_MULTILINE.getCode(), JDK_MULTILINE);
        flags.put(JDK_COMMENTS.getCode(), JDK_COMMENTS);
        flags.put(JDK_CASE_INSENSITIVE.getCode(), JDK_CASE_INSENSITIVE);
        flags.put(JDK_UNIX_LINES.getCode(), JDK_UNIX_LINES);
    }
    
    private JavaFlag(String code, int flag, String name, String description)
    {
        super(code, flag, name, description);
    }
}
