/*******************************************************************************
 * Copyright (c) 2005 Bastian Bergerhoff
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution.
 * 
 * Contributors:
 *     Bastian Bergerhoff - initial API and implementation
 *******************************************************************************/
package de.babe.eclipse.plugins.quickREx.regexp.oro.awk;

import java.util.regex.PatternSyntaxException;

import org.apache.oro.text.awk.AwkCompiler;
import org.apache.oro.text.awk.AwkMatcher;
import org.apache.oro.text.regex.MalformedPatternException;
import org.apache.oro.text.regex.PatternMatcherInput;

import de.babe.eclipse.plugins.quickREx.regexp.oro.OROMatchSet;

/**
 * @author bastian.bergerhoff
 */
public class OROAwkMatchSet extends OROMatchSet {

  /**
   * @param regExp
   * @param text
   */
  public OROAwkMatchSet(String regExp, String text) {
    super();
    try {
      AwkCompiler comp = new AwkCompiler();
      this.pattern = comp.compile(regExp);
      this.matcher = new AwkMatcher();
      this.text = text;
      this.input = new PatternMatcherInput(text);
    } catch (MalformedPatternException e) {
      throw new PatternSyntaxException(e.getMessage(), regExp, 0);
    }    
  }
}
