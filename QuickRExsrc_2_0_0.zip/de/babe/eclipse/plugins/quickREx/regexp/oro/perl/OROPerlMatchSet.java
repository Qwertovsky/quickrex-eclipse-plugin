/*******************************************************************************
 * Copyright (c) 2005 Bastian Bergerhoff
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution.
 * 
 * Contributors:
 *     Bastian Bergerhoff - initial API and implementation
 *******************************************************************************/
package de.babe.eclipse.plugins.quickREx.regexp.oro.perl;

import java.util.regex.PatternSyntaxException;

import org.apache.oro.text.regex.MalformedPatternException;
import org.apache.oro.text.regex.PatternMatcherInput;
import org.apache.oro.text.regex.Perl5Compiler;
import org.apache.oro.text.regex.Perl5Matcher;

import de.babe.eclipse.plugins.quickREx.regexp.oro.OROMatchSet;

/**
 * @author bastian.bergerhoff
 */
public class OROPerlMatchSet extends OROMatchSet {

  /**
   * @param regExp
   * @param text
   */
  public OROPerlMatchSet(String regExp, String text) {
    super();
    try {
      Perl5Compiler comp = new Perl5Compiler();
      this.pattern = comp.compile(regExp);
      this.matcher = new Perl5Matcher();
      this.text = text;
      this.input = new PatternMatcherInput(text);
    } catch (MalformedPatternException e) {
      throw new PatternSyntaxException(e.getMessage(), regExp, 0);
    }    
  }
}
