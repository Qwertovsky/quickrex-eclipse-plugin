/*******************************************************************************
 * Copyright (c) 2005 Bastian Bergerhoff
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution.
 * 
 * Contributors:
 *     Bastian Bergerhoff - initial API and implementation
 *******************************************************************************/
package de.babe.eclipse.plugins.quickREx.regexp;

import de.babe.eclipse.plugins.quickREx.regexp.jdk.JavaMatchSet;
import de.babe.eclipse.plugins.quickREx.regexp.oro.awk.OROAwkMatchSet;
import de.babe.eclipse.plugins.quickREx.regexp.oro.perl.OROPerlMatchSet;

/**
 * @author bastian.bergerhoff
 */
public class MatchSetFactory {

  public static final int JAVA_FLAVOUR = 1;
  public static final int ORO_PERL_FLAVOUR = 2;
  public static final int ORO_AWK_FLAVOUR = 4;

  /**
   * @param flavour
   * @param regExp
   * @param text
   * @return
   */
  public static MatchSet createMatchSet(int flavour, String regExp, String text) {
    switch (flavour) {
    case JAVA_FLAVOUR:
      return new JavaMatchSet(regExp, text);
    case ORO_PERL_FLAVOUR:
      return new OROPerlMatchSet(regExp, text);
    case ORO_AWK_FLAVOUR:
      return new OROAwkMatchSet(regExp, text);
    default:
      throw new IllegalArgumentException("Unknown Reg-Exp flavour requested: "+flavour);
    }
  }
}
