/*******************************************************************************
 * Copyright (c) 2005 Bastian Bergerhoff
 * All rights reserved. This program and the accompanying materials 
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution.
 * 
 * Contributors:
 *     Bastian Bergerhoff - initial API and implementation
 *******************************************************************************/
package de.babe.eclipse.plugins.quickREx.views;


import java.util.Map;
import java.util.regex.PatternSyntaxException;

import org.eclipse.jface.action.Action;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.action.IMenuManager;
import org.eclipse.jface.action.Separator;
import org.eclipse.jface.contentassist.ComboContentAssistSubjectAdapter;
import org.eclipse.jface.contentassist.SubjectControlContentAssistant;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.resource.JFaceResources;
import org.eclipse.jface.text.DefaultInformationControl;
import org.eclipse.jface.text.IDocument;
import org.eclipse.jface.text.IInformationControl;
import org.eclipse.jface.text.IInformationControlCreator;
import org.eclipse.jface.text.ITextSelection;
import org.eclipse.jface.text.TextSelection;
import org.eclipse.jface.text.contentassist.IContentAssistant;
import org.eclipse.swt.SWT;
import org.eclipse.swt.custom.StyleRange;
import org.eclipse.swt.custom.StyledText;
import org.eclipse.swt.events.FocusEvent;
import org.eclipse.swt.events.FocusListener;
import org.eclipse.swt.events.ModifyEvent;
import org.eclipse.swt.events.ModifyListener;
import org.eclipse.swt.events.SelectionEvent;
import org.eclipse.swt.events.SelectionListener;
import org.eclipse.swt.layout.GridData;
import org.eclipse.swt.layout.GridLayout;
import org.eclipse.swt.widgets.Button;
import org.eclipse.swt.widgets.Combo;
import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Display;
import org.eclipse.swt.widgets.Label;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IActionBars;
import org.eclipse.ui.IEditorPart;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.commands.AbstractHandler;
import org.eclipse.ui.commands.ExecutionException;
import org.eclipse.ui.commands.HandlerSubmission;
import org.eclipse.ui.commands.IHandler;
import org.eclipse.ui.commands.IWorkbenchCommandSupport;
import org.eclipse.ui.commands.Priority;
import org.eclipse.ui.part.ViewPart;
import org.eclipse.ui.texteditor.ITextEditor;
import org.eclipse.ui.texteditor.ITextEditorActionDefinitionIds;

import de.babe.eclipse.plugins.quickREx.PluginImageRegistry;
import de.babe.eclipse.plugins.quickREx.QuickRExPlugin;
import de.babe.eclipse.plugins.quickREx.StringUtils;
import de.babe.eclipse.plugins.quickREx.dialogs.OrganizeREsDialog;
import de.babe.eclipse.plugins.quickREx.dialogs.OrganizeTestTextDialog;
import de.babe.eclipse.plugins.quickREx.dialogs.SimpleTextDialog;
import de.babe.eclipse.plugins.quickREx.objects.RegularExpression;
import de.babe.eclipse.plugins.quickREx.regexp.Match;
import de.babe.eclipse.plugins.quickREx.regexp.RegExpContentAssistProcessor;
import de.babe.eclipse.plugins.quickREx.regexp.RegularExpressionHits;


/**
 * @author bastian.bergerhoff
 */
public class QuickRExView extends ViewPart {
	private Combo regExpCombo;
	private StyledText testText;
	private Label matches;
	private Label groups;
	private Button previousButton;
	private Button nextButton;
	private Button previousGroupButton;
	private Button nextGroupButton;
	private RegularExpressionHits hits = new RegularExpressionHits();
	private Button saveTextButton;
	private Button loadTextButton;
	private Action organizeREsAction;
	private Action organizeTestTextsAction;
  
	private static final String MATCH_BG_COLOR_KEY = "de.babe.eclipse.plugins.QuickREx.matchBgColor";
  private static final String MATCH_FG_COLOR_KEY = "de.babe.eclipse.plugins.QuickREx.matchFgColor";
  private static final String CURRENT_MATCH_BG_COLOR_KEY = "de.babe.eclipse.plugins.QuickREx.currentMatchBgColor";
  private static final String CURRENT_MATCH_FG_COLOR_KEY = "de.babe.eclipse.plugins.QuickREx.currentMatchFgColor";
  private static final String EDITOR_FONT_KEY = "de.babe.eclipse.plugins.QuickREx.textfontDefinition";
  private SubjectControlContentAssistant regExpContentAssistant;
  private HandlerSubmission regExpContentAssistantHandlerSubmission;
  private Action useJDKREAction;
  private Action useOROPerlREAction;
  private Action useOROAWKAction; 
  

	/**
	 * The constructor.
	 */
	public QuickRExView() {
	}

	/* (non-Javadoc)
	 * @see org.eclipse.ui.IWorkbenchPart#createPartControl(org.eclipse.swt.widgets.Composite)
	 */
	public void createPartControl(Composite parent) {
		createViewContents(parent);
		makeActions();
		contributeToActionBars();
	}

	private void createViewContents(Composite parent) {
		GridLayout layout = new GridLayout();
		layout.numColumns = 5;
		parent.setLayout(layout);

		// First row...
		Label regExpEnter = new Label(parent, SWT.NULL);
		regExpEnter.setText("Regular Expression:");
		GridData gd = new GridData();
		gd.grabExcessHorizontalSpace = false;
		regExpEnter.setLayoutData(gd);
		regExpCombo = new Combo(parent, SWT.DROP_DOWN);
		regExpCombo.setItems(QuickRExPlugin.getDefault().getRegularExpressions());
    regExpCombo.setFont(JFaceResources.getFont(EDITOR_FONT_KEY));
		gd = new GridData(GridData.HORIZONTAL_ALIGN_FILL);
		gd.horizontalSpan = 3;
		gd.grabExcessHorizontalSpace = true;
		regExpCombo.setLayoutData(gd);
		regExpCombo.addModifyListener(new ModifyListener(){
			public void modifyText(ModifyEvent p_e) {
				handleRegExpModified();
			}
		});
		regExpCombo.addFocusListener(new FocusListener(){
			public void focusGained(FocusEvent p_e) {
				// This is a hack to keep the Previous- and Next-Buttons from generating selections in the component... 
				regExpCombo.clearSelection();
			}

			public void focusLost(FocusEvent p_e) {
        // This is a hack to keep the Previous- and Next-Buttons from generating selections in the component... 
        regExpCombo.clearSelection();
			}
		});
		createRegExpContentAssist();
    Button keepButton = new Button(parent, SWT.PUSH);
    gd = new GridData(GridData.VERTICAL_ALIGN_END | GridData.HORIZONTAL_ALIGN_FILL);
    gd.grabExcessHorizontalSpace = false;
    keepButton.setLayoutData(gd);
    keepButton.setText("&Keep");
    keepButton.addSelectionListener(new SelectionListener(){
      public void widgetSelected(SelectionEvent p_e) {
        handleKeepButtonPressed();
      }
      public void widgetDefaultSelected(SelectionEvent p_e) {
      }
    });

		// Second row (a)...
		Label testTextEnter = new Label(parent, SWT.NULL);
		testTextEnter.setText("Test-Text:");
		gd = new GridData(GridData.VERTICAL_ALIGN_BEGINNING);
		gd.grabExcessHorizontalSpace = false;
		gd.verticalSpan = 2;
		testTextEnter.setLayoutData(gd);		
		testText = new StyledText(parent, SWT.BORDER | SWT.MULTI | SWT.H_SCROLL | SWT.V_SCROLL);
    testText.setFont(JFaceResources.getFont(EDITOR_FONT_KEY));
		gd = new GridData(GridData.HORIZONTAL_ALIGN_FILL | GridData.VERTICAL_ALIGN_FILL);
		gd.grabExcessHorizontalSpace = true;
		gd.grabExcessVerticalSpace = true;
		gd.horizontalSpan = 3;
		gd.verticalSpan = 2;
		testText.setLayoutData(gd);
		testText.addModifyListener(new ModifyListener(){
			public void modifyText(ModifyEvent p_e) {
				handleTestTextModified();
			}
		});
		saveTextButton = new Button(parent, SWT.PUSH);
		gd = new GridData(GridData.VERTICAL_ALIGN_BEGINNING | GridData.HORIZONTAL_ALIGN_FILL);
		gd.grabExcessHorizontalSpace = false;
		saveTextButton.setLayoutData(gd);
		saveTextButton.setText("&Save");
		saveTextButton.addSelectionListener(new SelectionListener(){
			public void widgetSelected(SelectionEvent p_e) {
				handleSaveTextButtonPressed();
			}
			public void widgetDefaultSelected(SelectionEvent p_e) {
			}
		});

		// Second row (b)...
		loadTextButton = new Button(parent, SWT.PUSH);
		gd = new GridData(GridData.VERTICAL_ALIGN_BEGINNING | GridData.HORIZONTAL_ALIGN_FILL);
		gd.grabExcessHorizontalSpace = false;
		loadTextButton.setLayoutData(gd);
		loadTextButton.setText("&Load");
		loadTextButton.addSelectionListener(new SelectionListener(){
			public void widgetSelected(SelectionEvent p_e) {
				handleLoadTextButtonPressed();
			}
			public void widgetDefaultSelected(SelectionEvent p_e) {
			}
		});
		
		// Third row...
		Label regExpResult = new Label(parent, SWT.NULL);
		regExpResult.setText("Matches:");
		gd = new GridData();
		gd.grabExcessHorizontalSpace = false;
		regExpResult.setLayoutData(gd);
		previousButton = new Button(parent, SWT.PUSH);
		gd = new GridData();
		gd.grabExcessHorizontalSpace = false;
		previousButton.setLayoutData(gd);
		previousButton.setText("&Previous");
		previousButton.addSelectionListener(new SelectionListener(){
			public void widgetSelected(SelectionEvent p_e) {
				handlePreviousButtonPressed();
			}
			public void widgetDefaultSelected(SelectionEvent p_e) {
			}
		});
		previousButton.setEnabled(false);
		nextButton = new Button(parent, SWT.PUSH);
		gd = new GridData(GridData.VERTICAL_ALIGN_END | GridData.HORIZONTAL_ALIGN_FILL);
		gd.grabExcessHorizontalSpace = false;
		nextButton.setLayoutData(gd);
		nextButton.setText("&Next");
		nextButton.addSelectionListener(new SelectionListener(){
			public void widgetSelected(SelectionEvent p_e) {
				handleNextButtonPressed();
			}
			public void widgetDefaultSelected(SelectionEvent p_e) {
			}
		});
		nextButton.setEnabled(false);
		matches = new Label(parent, SWT.LEFT);
		matches.setText("Not evaluated yet...");
		gd = new GridData(GridData.HORIZONTAL_ALIGN_FILL);
		gd.grabExcessHorizontalSpace = true;
		matches.setLayoutData(gd);
    Button copyToJavaClipboardButton = new Button(parent, SWT.PUSH);
    gd = new GridData(GridData.VERTICAL_ALIGN_END | GridData.HORIZONTAL_ALIGN_FILL);
    gd.grabExcessHorizontalSpace = false;
    copyToJavaClipboardButton.setLayoutData(gd);
    copyToJavaClipboardButton.setText("JCopy");
    copyToJavaClipboardButton.addSelectionListener(new SelectionListener(){
      public void widgetSelected(SelectionEvent p_e) {
        handleCopyButtonPressed();
      }
      public void widgetDefaultSelected(SelectionEvent p_e) {
      }
    });
		
		// Fourth row...
		Label groupsLabel = new Label(parent, SWT.NULL);
		groupsLabel.setText("Groups:");
		gd = new GridData();
		gd.grabExcessHorizontalSpace = false;
		groupsLabel.setLayoutData(gd);
		previousGroupButton = new Button(parent, SWT.PUSH);
		gd = new GridData();
		gd.grabExcessHorizontalSpace = false;
		previousGroupButton.setLayoutData(gd);
		previousGroupButton.setText("P&revious");
		previousGroupButton.addSelectionListener(new SelectionListener(){
			public void widgetSelected(SelectionEvent p_e) {
				handlePreviousGroupButtonPressed();
			}
			public void widgetDefaultSelected(SelectionEvent p_e) {
			}
		});
		previousGroupButton.setEnabled(false);
		nextGroupButton = new Button(parent, SWT.PUSH);
		gd = new GridData(GridData.VERTICAL_ALIGN_END);
		gd.grabExcessHorizontalSpace = false;
		nextGroupButton.setLayoutData(gd);
		nextGroupButton.setText("N&ext");
		nextGroupButton.addSelectionListener(new SelectionListener(){
			public void widgetSelected(SelectionEvent p_e) {
				handleNextGroupButtonPressed();
			}
			public void widgetDefaultSelected(SelectionEvent p_e) {
			}
		});
		nextGroupButton.setEnabled(false);
		groups = new Label(parent, SWT.LEFT);
		groups.setText("");
		gd = new GridData(GridData.HORIZONTAL_ALIGN_FILL);
		gd.grabExcessHorizontalSpace = true;
		groups.setLayoutData(gd);
    Button grepButton = new Button(parent, SWT.PUSH);
    gd = new GridData(GridData.VERTICAL_ALIGN_END | GridData.HORIZONTAL_ALIGN_FILL);
    gd.grabExcessHorizontalSpace = false;
    grepButton.setLayoutData(gd);
    grepButton.setText("Grep...");
    grepButton.addSelectionListener(new SelectionListener(){
      public void widgetSelected(SelectionEvent p_e) {
        handleGrepButtonPressed();
      }
      public void widgetDefaultSelected(SelectionEvent p_e) {
      }
    });
  }

  private void createRegExpContentAssist() {
    regExpContentAssistant = new SubjectControlContentAssistant();
    regExpContentAssistant.enableAutoActivation(false);
    regExpContentAssistant.enableAutoInsert(true);
    regExpContentAssistant.setContentAssistProcessor(new RegExpContentAssistProcessor(), IDocument.DEFAULT_CONTENT_TYPE);
    regExpContentAssistant.setContextInformationPopupOrientation(IContentAssistant.CONTEXT_INFO_ABOVE);
    regExpContentAssistant.setRestoreCompletionProposalSize(QuickRExPlugin.getDefault().getDialogSettings()); //$NON-NLS-1$
    regExpContentAssistant.setInformationControlCreator(new IInformationControlCreator() {
      /*
       * @see org.eclipse.jface.text.IInformationControlCreator#createInformationControl(org.eclipse.swt.widgets.Shell)
       */
      public IInformationControl createInformationControl(Shell parent) {
        return new DefaultInformationControl(parent);
      }});
    regExpContentAssistant.install(new ComboContentAssistSubjectAdapter(regExpCombo));
    IHandler handler= new AbstractHandler() {
      public Object execute(Map parameterValuesByName) throws ExecutionException {
        regExpContentAssistant.showPossibleCompletions();
        return null;
      }
    };
    regExpContentAssistantHandlerSubmission = new HandlerSubmission(null, regExpCombo.getShell(), null,
        ITextEditorActionDefinitionIds.CONTENT_ASSIST_PROPOSALS, handler, Priority.MEDIUM);
    IWorkbenchCommandSupport commandSupport = PlatformUI.getWorkbench().getCommandSupport();
    commandSupport.addHandlerSubmission(regExpContentAssistantHandlerSubmission);
  }

  private void makeActions() {
		organizeREsAction = new Action() {
			public void run() {
				handleOrganizeREs();
			}
		};
		organizeREsAction.setText("Organize Reg. Exp.s...");
		organizeREsAction.setToolTipText("Organize the Regular Expressions kept in history...");
		organizeREsAction.setImageDescriptor(((PluginImageRegistry)QuickRExPlugin.getDefault().getImageRegistry())
        .getImageDescriptor(PluginImageRegistry.IMG_ORGANIZE_RES));
		
		organizeTestTextsAction = new Action() {
			public void run() {
				handleOrganizeTexts();
			}
		};
		organizeTestTextsAction.setText("Organize Test-Texts...");
		organizeTestTextsAction.setToolTipText("Organize the Test Texts kept in history...");
    organizeTestTextsAction.setImageDescriptor(((PluginImageRegistry)QuickRExPlugin.getDefault().getImageRegistry())
        .getImageDescriptor(PluginImageRegistry.IMG_ORGANIZE_TEXTS));
    
    useJDKREAction = new Action("", IAction.AS_RADIO_BUTTON) {
      public void run() {
        if (isChecked()) {
          setUseJavaRE();
        }
      }
    };
    useJDKREAction.setText("Java (JDK) Reg. Exp.s");
    useJDKREAction.setToolTipText("Use the JDK-provided Regular Expressions implementation");
    useJDKREAction.setChecked(QuickRExPlugin.getDefault().isUsingJavaRE());
    useJDKREAction.setImageDescriptor(((PluginImageRegistry)QuickRExPlugin.getDefault().getImageRegistry())
        .getImageDescriptor(PluginImageRegistry.IMG_JAVA_LOGO));
    
    useOROPerlREAction = new Action("", IAction.AS_RADIO_BUTTON) {
      public void run() {
        if (isChecked()) {
          setUseOROPerlRE();
        }
      }
    };
    useOROPerlREAction.setText("ORO Perl 5 Reg. Exp.s");
    useOROPerlREAction.setToolTipText("Use the Jakarta-ORO Perl 5 Regular Expressions implementation");
    useOROPerlREAction.setChecked(QuickRExPlugin.getDefault().isUsingOROPerlRE());
    useOROPerlREAction.setImageDescriptor(((PluginImageRegistry)QuickRExPlugin.getDefault().getImageRegistry())
        .getImageDescriptor(PluginImageRegistry.IMG_ORO_LOGO));
    
    useOROAWKAction = new Action("", IAction.AS_RADIO_BUTTON) {
      public void run() {
        if (isChecked()) {
          setUseOROAwkRE();
        }
      }
    };
    useOROAWKAction.setText("ORO AWK Reg. Exp.s");
    useOROAWKAction.setToolTipText("Use the Jakarta-ORO AWK Regular Expressions implementation");
    useOROAWKAction.setChecked(QuickRExPlugin.getDefault().isUsingOROAwkRE());
    useOROAWKAction.setImageDescriptor(((PluginImageRegistry)QuickRExPlugin.getDefault().getImageRegistry())
        .getImageDescriptor(PluginImageRegistry.IMG_ORO_LOGO));
	}

  private void contributeToActionBars() {
		IActionBars bars = getViewSite().getActionBars();
		fillLocalPullDown(bars.getMenuManager());
	}

	private void fillLocalPullDown(IMenuManager manager) {
    manager.add(useJDKREAction);
    manager.add(useOROPerlREAction);
    manager.add(useOROAWKAction);
    manager.add(new Separator("StoreHandleSeparator"));
		manager.add(organizeREsAction);
		manager.add(organizeTestTextsAction);
	}

	private void showMessage(String p_title, String p_message) {
		MessageDialog.openInformation(getSite().getShell(),
				p_title, p_message);
	}

	private void redrawThirdLine() {
		nextButton.redraw();
		previousButton.redraw();
		matches.redraw();
	}

	private void redrawFourthLine() {
		nextGroupButton.redraw();
		previousGroupButton.redraw();
		groups.redraw();
	}

  private ITextEditor getActiveEditor() {
    IEditorPart ePart = PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().getActiveEditor();
    if (PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().getActiveEditor() instanceof ITextEditor) {
      return (ITextEditor)PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().getActiveEditor();      
    } else {
      return null;
    }
  }

  protected void setUseJavaRE() {
    QuickRExPlugin.getDefault().useJavaRE();
    // This is a hack since there is no direct way of getting rid of the completion-proposal popup... 
    String oldRegExp = regExpCombo.getText();
    regExpCombo.setText(oldRegExp+" ");
    regExpCombo.setText(oldRegExp);
    updateEvaluation();
  }

  protected void setUseOROPerlRE() {
    QuickRExPlugin.getDefault().useOROPerlRE();
    // This is a hack since there is no direct way of getting rid of the completion-proposal popup... 
    String oldRegExp = regExpCombo.getText();
    regExpCombo.setText(oldRegExp+" ");
    regExpCombo.setText(oldRegExp);
    updateEvaluation();
  }

  protected void setUseOROAwkRE() {
    QuickRExPlugin.getDefault().useOROAwkRE();
    // This is a hack since there is no direct way of getting rid of the completion-proposal popup... 
    String oldRegExp = regExpCombo.getText();
    regExpCombo.setText(oldRegExp+" ");
    regExpCombo.setText(oldRegExp);
    updateEvaluation();
  }

	private void handleOrganizeREs() {
		OrganizeREsDialog dlg = new OrganizeREsDialog(getSite().getShell());
		dlg.open();
    regExpCombo.setItems(QuickRExPlugin.getDefault().getRegularExpressions());
	}

	private void handleOrganizeTexts() {
		OrganizeTestTextDialog dlg = new OrganizeTestTextDialog(getSite().getShell(), OrganizeTestTextDialog.TYPE_ORGANIZE);
		dlg.open();
	}

  private void handleGrepButtonPressed() {
    SimpleTextDialog dlg = new SimpleTextDialog(getSite().getShell(), "QuickREx - Grep", hits.grep());
    dlg.open();
  }

  private void handleCopyButtonPressed() {
    copyToEditor(StringUtils.escapeForJava(regExpCombo.getText()));
  }

  private void copyToEditor(String string) {
    try {
      int currentOffset = ((ITextSelection)getActiveEditor().getSelectionProvider().getSelection()).getOffset();
      int currentLength = ((ITextSelection)getActiveEditor().getSelectionProvider().getSelection()).getLength();
      getActiveEditor().getDocumentProvider().getDocument(getActiveEditor().getEditorInput()).replace(currentOffset, currentLength, string);
      getActiveEditor().getSelectionProvider().setSelection(new TextSelection(currentOffset, string.length()));
    } catch (Throwable t) {
      // nop...
    }
  }

  private void handleLoadTextButtonPressed() {
		OrganizeTestTextDialog dlg = new OrganizeTestTextDialog(getSite().getShell(), OrganizeTestTextDialog.TYPE_LOAD);
		dlg.open();
		if (dlg.getSelectedText() != null) {
			testText.setText(dlg.getSelectedText().getText());
		}
	}

	private void handleSaveTextButtonPressed() {
		OrganizeTestTextDialog dlg = new OrganizeTestTextDialog(getSite().getShell(), OrganizeTestTextDialog.TYPE_SAVE);
		dlg.setTextToSave(testText.getText());
		dlg.open();
		if (dlg.getSaveInformation() != null) {
			QuickRExPlugin.getDefault().addTestText(dlg.getSaveInformation());
		}
	}

	private void handleNextGroupButtonPressed() {
		hits.getCurrentMatch().toNextGroup();
		groups.setText(""+hits.getCurrentMatch().getNumberOfGroups()+", current is number "+hits.getCurrentMatch().getCurrentGroup().getIndex()+" ('"+hits.getCurrentMatch().getCurrentGroup().getText()+"')");
		nextGroupButton.setEnabled(hits.getCurrentMatch().hasNextGroup());
		previousGroupButton.setEnabled(hits.getCurrentMatch().hasPreviousGroup());
    updateMatchView(hits.getCurrentMatch());
	}

	private void handlePreviousGroupButtonPressed() {
		hits.getCurrentMatch().toPreviousGroup();
		groups.setText(""+hits.getCurrentMatch().getNumberOfGroups()+", current is number "+hits.getCurrentMatch().getCurrentGroup().getIndex()+" ('"+hits.getCurrentMatch().getCurrentGroup().getText()+"')");
		nextGroupButton.setEnabled(hits.getCurrentMatch().hasNextGroup());
		previousGroupButton.setEnabled(hits.getCurrentMatch().hasPreviousGroup());		
    updateMatchView(hits.getCurrentMatch());
	}

	private void handleNextButtonPressed() {
		hits.toNextMatch();
		Match match = hits.getCurrentMatch();
		matches.setText(""+hits.getNumberOfMatches()+", current is from "+match.getStart()+" to "+match.getEnd());
    updateMatchView(match);
		nextButton.setEnabled(hits.hasNextMatch());
		previousButton.setEnabled(hits.hasPreviousMatch());
		if (hits.getCurrentMatch().getNumberOfGroups() > 0) {
			groups.setText(""+hits.getCurrentMatch().getNumberOfGroups()+", current is number "+hits.getCurrentMatch().getCurrentGroup().getIndex()+" ('"+hits.getCurrentMatch().getCurrentGroup().getText()+"')");
		} else {
			groups.setText("none");
		}
		nextGroupButton.setEnabled(hits.getCurrentMatch().hasNextGroup());
		previousGroupButton.setEnabled(hits.getCurrentMatch().hasPreviousGroup());		
	}

  private void handlePreviousButtonPressed() {
		hits.toPreviousMatch();
		Match match = hits.getCurrentMatch();
		matches.setText(""+hits.getNumberOfMatches()+", current is from "+match.getStart()+" to "+match.getEnd());
		updateMatchView(match);
		nextButton.setEnabled(hits.hasNextMatch());
		previousButton.setEnabled(hits.hasPreviousMatch());
		if (hits.getCurrentMatch().getNumberOfGroups() > 0) {
			groups.setText(""+hits.getCurrentMatch().getNumberOfGroups()+", current is number "+hits.getCurrentMatch().getCurrentGroup().getIndex()+" ('"+hits.getCurrentMatch().getCurrentGroup().getText()+"')");
		} else {
			groups.setText("none");
		}
		nextGroupButton.setEnabled(hits.getCurrentMatch().hasNextGroup());
		previousGroupButton.setEnabled(hits.getCurrentMatch().hasPreviousGroup());		
	}

	private void handleTestTextModified() {
    updateEvaluation();
	}

  private void handleRegExpModified() {
    updateEvaluation();
	}

  private void updateMatchView(Match match) {
    testText.setStyleRange(new StyleRange(0, testText.getText().length(), null, null));
    if (hits.getAllMatches() != null && hits.getAllMatches().length > 0) {
      testText.setStyleRanges(getStyleRanges(hits.getAllMatches()));
    }
    if (match != null) {
      testText.setStyleRange(new StyleRange(match.getStart(), match.getEnd()-match.getStart(), JFaceResources.getColorRegistry().get(CURRENT_MATCH_FG_COLOR_KEY), JFaceResources.getColorRegistry().get(CURRENT_MATCH_BG_COLOR_KEY), SWT.NORMAL));
      if (match.getCurrentGroup() != null) {
        testText.setStyleRange(new StyleRange(match.getCurrentGroup().getStart(), match.getCurrentGroup().getEnd()-match.getCurrentGroup().getStart(), JFaceResources.getColorRegistry().get(CURRENT_MATCH_FG_COLOR_KEY), JFaceResources.getColorRegistry().get(CURRENT_MATCH_BG_COLOR_KEY), SWT.BOLD));
      }
      // scroll horizontally if needed
      testText.setTopIndex(testText.getLineAtOffset(match.getStart()));
    }
  }

  private StyleRange[] getStyleRanges(Match[] p_matches) {
    StyleRange[] ranges = new StyleRange[p_matches.length];
    for (int i = 0; i < p_matches.length; i++) {
      ranges[i] = new StyleRange(p_matches[i].getStart(), p_matches[i].getEnd()-p_matches[i].getStart(), JFaceResources.getColorRegistry().get(MATCH_FG_COLOR_KEY), JFaceResources.getColorRegistry().get(MATCH_BG_COLOR_KEY));
    }
    return ranges;
  }

  private void updateEvaluation() {
    if (regExpCombo.getText() != null && testText.getText() != null) {
      try {
        matches.setForeground(null);
        hits.init(regExpCombo.getText(), testText.getText());
        if (hits.containsMatches()) {
          Match match = hits.getCurrentMatch();
          updateMatchView(match);
          matches.setText(""+hits.getNumberOfMatches()+", current is from "+match.getStart()+" to "+match.getEnd());
          nextButton.setEnabled(hits.hasNextMatch());
          previousButton.setEnabled(hits.hasPreviousMatch());
          if (hits.getCurrentMatch().getNumberOfGroups() > 0) {
            groups.setText(""+hits.getCurrentMatch().getNumberOfGroups()+", current is number "+hits.getCurrentMatch().getCurrentGroup().getIndex()+" ('"+hits.getCurrentMatch().getCurrentGroup().getText()+"')");
          } else {
            groups.setText("none");
          }
          nextGroupButton.setEnabled(hits.getCurrentMatch().hasNextGroup());
          previousGroupButton.setEnabled(hits.getCurrentMatch().hasPreviousGroup());
        } else {
          updateMatchView(null);
          matches.setText("none");
          groups.setText("");
          nextButton.setEnabled(false);
          previousButton.setEnabled(false);
          nextGroupButton.setEnabled(false);
          previousGroupButton.setEnabled(false);
        }
      } catch (PatternSyntaxException pse) {
        matches.setText("Illegal Pattern: "+StringUtils.firstLine(pse.getMessage()));
        matches.setForeground(Display.getCurrent().getSystemColor(SWT.COLOR_DARK_RED));
        hits.reset();
        updateMatchView(null);
        regExpCombo.setFocus();
        groups.setText("");
        nextButton.setEnabled(false);
        previousButton.setEnabled(false);
        nextGroupButton.setEnabled(false);
        previousGroupButton.setEnabled(false);
      }
      redrawThirdLine();
      redrawFourthLine();
    }
  }

	private void handleKeepButtonPressed() {
		regExpCombo.add(regExpCombo.getText(), 0);
		QuickRExPlugin.getDefault().addRegularExpression(new RegularExpression(regExpCombo.getText()));
	}

  /* (non-Javadoc)
   * @see org.eclipse.ui.part.WorkbenchPart#setFocus()
   */
  public void setFocus() {
  }
  
  /* (non-Javadoc)
   * @see org.eclipse.ui.IWorkbenchPart#dispose()
   */
  public void dispose() {
    IWorkbenchCommandSupport commandSupport = PlatformUI.getWorkbench().getCommandSupport();
    commandSupport.removeHandlerSubmission(regExpContentAssistantHandlerSubmission);
    super.dispose();
  }
}